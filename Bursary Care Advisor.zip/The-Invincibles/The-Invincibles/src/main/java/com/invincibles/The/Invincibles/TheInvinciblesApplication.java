package com.invincibles.The.Invincibles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheInvinciblesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheInvinciblesApplication.class, args);
	}

}
