/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.University;
import za.ac.tut.model.UniversityManager;



/**
 *
 * @author boika
 */
public class UniversityServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            UniversityManager adminManage = new UniversityManager("jdbc:mysql://192.168.43.79:3306/bursarycareadvisordb?useSSL=false&&allowPublicKeyRetrieval=true", "stoz", "stozay");

            String option = request.getParameter("option");

            if (option.equals("add")) {
                Integer universityId = Integer.parseInt(request.getParameter("universityid"));
                String name = request.getParameter("name");
                String location = request.getParameter("location");
                Integer id = Integer.parseInt(request.getParameter("id"));
                
                //New code
                String gender = request.getParameter("gender");
                String date = request.getParameter("birthday");

                //Part filePart = (Part) request.getPart("universityAccletter");
                //String fileName = Paths.get(filePart.getFileName()).toString();
                University university = new University(universityId, name, location, id,gender , date);

                boolean add = adminManage.add(university);
                if (add = true) {
                    request.getRequestDispatcher("UniversityAddConfirmation.jsp").forward(request, response);

                } else {
                    request.getRequestDispatcher("confirmation.jsp").forward(request, response);
                }

            } else if (option.equals("search")) {

                Integer universityId = Integer.parseInt(request.getParameter("universityId"));

                String universityResults = adminManage.searchApplicant(universityId);

                request.setAttribute("universityResults", universityResults);

                request.getRequestDispatcher("UniversitySearchOutcome.jsp").forward(request, response);

            } else if (option.equals("delete")) {
                Integer idNo = Integer.parseInt(request.getParameter("id"));

                Boolean resultsDelete = adminManage.delete(idNo);
                request.setAttribute("id", idNo);
                if (resultsDelete) {
                    request.getRequestDispatcher("UniversityDeleteOut.jsp").forward(request, response);
                }

            } else if (option.equals("update")) {

                String location = request.getParameter("location");
                String name = request.getParameter("name");
                // Integer phoneNumber = Integer.parseInt(request.getParameter("phoneNumber"));
                // String status = request.getParameter("status");
                Integer id = Integer.parseInt(request.getParameter("id"));

                University newApp = new University();
                newApp.setApplicantNumber(id);
                newApp.setLocation(location);
                // newApp.setPhoneNumber(phoneNumber);
                newApp.setName(name);
                // newApp.setApplicantNumber(id);

                Boolean update = adminManage.update(newApp);
                request.setAttribute("id", id);
                if (update == true) {

                    request.getRequestDispatcher("UniversityUpdateOutcome.jsp").forward(request, response);
                } else {
                    System.err.println("Error");
                }

            } else if (option.equals("getAll")) {
                  List<University> list = adminManage.getAllApplicant();
                
                request.setAttribute("list", list);
                
                request.getRequestDispatcher("getAllTheUniversities.jsp").forward(request, response);
                

            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UniversityServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(UniversityServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
