/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.sql.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.Applicant;
import za.ac.tut.model.ApplicantManager;

/**
 *
 * @author boika
 */
public class ApplicantServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // String usernameDB = request.getParameter("stoz");
            //String passwordDB = request.getParameter("stozay");
            //String urlDB = "jdbc:mysql://192.168.85.214:3306/credentials_db?useSSL=false&&allowPublicKeyRetrieval=true";

            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connection connection = DriverManager.getConnection("jdbc:mysql://192.168.115.214:3306/credentials_db?useSSL=false&&allowPublicKeyRetrieval=true", "stoz", "stozay");
            //  Connection connection = DriverManager.getConnection("jdbc:mysql://192.168.115.214:3306/credentials_db?useSSL=false&&allowPublicKeyRetrieval=true", "stoz", "stozay");
            ApplicantManager applicantManager = new ApplicantManager("jdbc:derby://localhost:1527/BursaryCareAdvisorDB", "app", "123");
            
            String option = request.getParameter("option");
            
            if (option.equals("add")) {
                String username = request.getParameter("username");
                String firstname = request.getParameter("firstname");
                String lastname = request.getParameter("lastname");
                Integer id = Integer.parseInt(request.getParameter("idNumber"));
                String phoneNumber = request.getParameter("phoneNumber");
                String email = request.getParameter("email");
                
                String gender = request.getParameter("gender");
                
                String password = request.getParameter("password");
                // String confirmPassword = request.getParameter("confirmPassword");
                String birthday = request.getParameter("birthday");
                
                Applicant applicant = new Applicant();
                
                applicant.setUsername(username);
                applicant.setFirstName(firstname);
                applicant.setLastName(lastname);
                applicant.setApplicantNumber(id);
                applicant.setGender(gender);
                applicant.setBirthday(birthday);
                applicant.setPhoneNumber(Integer.parseInt(phoneNumber));
                applicant.setPassword(password);
                applicant.setStatus("Submitted");
                
                applicant.setEmail(email);
                
                boolean rowsAffected = applicantManager.add(applicant);
                
                if (rowsAffected == true) {
                    request.getRequestDispatcher("confirmationApplicant.jsp").forward(request, response);
                } else {
                    request.getRequestDispatcher("confirmation.jsp").forward(request, response);
                }
                
            } else if (option.equals("Reset")) {
                
                Integer idNo = Integer.parseInt(request.getParameter("id"));
                
                String applicantResults = applicantManager.searchApplicant(idNo);
                
                request.setAttribute("applicantResults", applicantResults);
                
                request.getRequestDispatcher("ApplicantSearchOutcome.jsp").forward(request, response);
                
            } else if (option.equals("delete")) {
                Integer idNo = Integer.parseInt(request.getParameter("id"));
                
                Boolean resultsDelete = applicantManager.delete(idNo);
                request.getRequestDispatcher("DeleteApplicantOutcome.jsp").forward(request, response);
                
            } else if (option.equals("getAll")) {
                List<Applicant> list = applicantManager.getAllApplicant();
                
                request.setAttribute("list", list);
                
                request.getRequestDispatcher("getAllTheApplicants.jsp").forward(request, response);
                
            } else if (option.equals("update")) {
                
                String univerAccLetter = request.getParameter("univerAccLetter");
                String email = request.getParameter("email");
                // Integer phoneNumber = Integer.parseInt(request.getParameter("phoneNumber"));
                String status = request.getParameter("status");
                Integer id = Integer.parseInt(request.getParameter("id"));
                
                Applicant newApp = new Applicant();
                newApp.setUniverAccLetter(univerAccLetter);
                newApp.setEmail(email);
                // newApp.setPhoneNumber(phoneNumber);
                newApp.setStatus(status);
                newApp.setApplicantNumber(id);
                
                Boolean update = applicantManager.update(newApp);
                request.setAttribute("id", id);
                if (update == true) {
                    
                    request.getRequestDispatcher("ApplicantUpdateOutcome.jsp").forward(request, response);
                    
                } else {
                    System.err.println("Error");
                }
                
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ApplicantServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ApplicantServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
