/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import za.ac.tut.model.Administrator;
import za.ac.tut.model.AdministratorManager;
import za.ac.tut.model.Image;

/**
 *
 * @author boika
 */

@MultipartConfig
public class AdministratorServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            AdministratorManager adminManage = new AdministratorManager("jdbc:mysql://192.168.43.79:3306/bursarycareadvisordb?useSSL=false&&allowPublicKeyRetrieval=true", "stoz", "stozay");

            String option = request.getParameter("option");

            if (option.equals("add")) {

                //retrieving the image from the web-page.
                Part imagePart = request.getPart("image");

                String adminNumber = request.getParameter("adminNumber");
                String username = request.getParameter("username");
                String password = request.getParameter("password");
                String email = request.getParameter("email");
                String status = request.getParameter("status");
                String applicantNumber = request.getParameter("applicantNumber");

                //New code
                String gender = request.getParameter("gender");
                String date = request.getParameter("birthday");

                //the actual image path in string 
                String imageName = imagePart.getSubmittedFileName();

                //Converting the image using the InputStream to byte[]
                byte[] image = getByteFromInputStream(imagePart.getInputStream());

                //adding the image to the list.
                //List<Image> images = new ArrayList<>();
                //images.add(new Image(imageName, image));

                Administrator admin = new Administrator(Integer.parseInt(adminNumber), username, password, email, gender, date, status, Integer.parseInt(applicantNumber));
                admin.setImage(image);

                boolean isAdded = adminManage.add(admin);

                if (isAdded == true) {
                    request.getRequestDispatcher("confirmAdmin.jsp").forward(request, response);
                } else {
                    request.getRequestDispatcher("confirmation.jsp").forward(request, response);
                }

            } else if (option.equals("search")) {
                Integer idNo = Integer.parseInt(request.getParameter("adminNumber"));

                String adminResults = adminManage.searchApplicant(idNo);

                request.setAttribute("adminResults", adminResults);

                request.getRequestDispatcher("AdministratorSearchOut.jsp").forward(request, response);

            } else if (option.equals("delete")) {

                Integer idNo = Integer.parseInt(request.getParameter("applicantNumber"));

                Boolean resultsDelete = adminManage.delete(idNo);

                if (resultsDelete) {
                    request.getRequestDispatcher("AdministratorDeleteOut.jsp").forward(request, response);
                }
            } else if (option.equals("getAll")) {

                ArrayList<Administrator> list = adminManage.getAllApplicant();

                request.setAttribute("list", list);

                request.getRequestDispatcher("AdministratorsGetAll.jsp").forward(request, response);
            } else if (option.equals("update")) {
                
                
                     Part imagePart = request.getPart("image");

                 String imageName = imagePart.getSubmittedFileName();

                //Converting the image using the InputStream to byte[]
                byte[] image = getByteFromInputStream(imagePart.getInputStream());

                Integer id = Integer.parseInt(request.getParameter("adminNumber"));

                Administrator newAd = new Administrator();

                newAd.setAdminNumber(id);
                newAd.setImage(image);
                

                boolean isTrue = adminManage.update(newAd);

                request.setAttribute("id", id);
                if (isTrue == true) {

                    request.getRequestDispatcher("AdministratorUpdateOut.jsp").forward(request, response);
                } else {
                    System.err.println("Error");
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ApplicantServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private byte[] getByteFromInputStream(InputStream inputStream) {
        byte[] buffer = null;

        try {
            buffer = new byte[inputStream.available()];
            inputStream.read(buffer);
            inputStream.close();

        } catch (IOException ex) {
            Logger.getLogger(AdministratorServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        return buffer;
    }

}
