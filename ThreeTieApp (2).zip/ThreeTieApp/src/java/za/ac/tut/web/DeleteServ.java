/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.Administrator;
import za.ac.tut.model.AdministratorManager;
import za.ac.tut.model.Applicant;
import za.ac.tut.model.ApplicantManager;



/**
 *
 * @author User
 */
public class DeleteServ extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            AdministratorManager applicantManage = new AdministratorManager("jdbc:mysql://192.168.43.79:3306/bursarycareadvisordb?useSSL=false&&allowPublicKeyRetrieval=true", "stoz", "stozay");

            List<Administrator> applicants = applicantManage.getAllApplicant();
            
        

            request.setAttribute("list", applicants);

            request.getRequestDispatcher("DeleteAdministrator.jsp").forward(request, response);

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ListToAdmin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ListToAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
