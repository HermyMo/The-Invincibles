/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import za.ac.tut.model.Administrator;
import za.ac.tut.model.AdministratorManager;
import za.ac.tut.model.Applicant;
import za.ac.tut.model.ApplicantManager;
import za.ac.tut.model.Bursary_Interviewer;

/**
 *
 * @author boika
 */
@MultipartConfig
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();

        String username = request.getParameter("logUsername");
        String password = request.getParameter("password");
        String opt = request.getParameter("opt");
        String selectedOption = request.getParameter("role");

        if (selectedOption != null) {
            if (selectedOption.equalsIgnoreCase("applicant")) {
                try {

                    ApplicantManager applicantManager = new ApplicantManager("jdbc:derby://localhost:1527/BursaryCareAdvisorDB", "app", "123");
                    Applicant app = applicantManager.viewApplicant(username);

                    if (username.equals(app.getUsername())) {

                        String firstname = app.getFirstName();
                        String lastname = app.getLastName();
                        String dob = app.getLastName();
                        String email = app.getEmail();
                        String gender = app.getGender();
                        Integer id = app.getApplicantNumber();
                        String birthday = app.getBirthday();
                        String status = app.getStatus();
                        Integer cellNumber = app.getPhoneNumber();

                        session.setAttribute("firstname", firstname);
                        session.setAttribute("lastname", lastname);
                        session.setAttribute("dob", dob);
                        session.setAttribute("birthday", birthday);
                        session.setAttribute("gender", gender);
                        session.setAttribute("email", email);
                        session.setAttribute("id", id);
                        session.setAttribute("cellNumber", cellNumber);
                        session.setAttribute("status", status);

                        request.getRequestDispatcher("ApplicantLogin.jsp").forward(request, response);

                    } else {

                        String use = "Incorrect Username or Password! ";

                        request.setAttribute("incorrectUsername", use);

                        request.getRequestDispatcher("login.jsp").forward(request, response);

                    }

                } catch (SQLException ex) {
                    Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if (selectedOption.equalsIgnoreCase("administrator")) {

                try {
                    AdministratorManager manager = new AdministratorManager("jdbc:derby://localhost:1527/BursaryCareAdvisorDB", "app", "123");
                    ApplicantManager applicantManager = new ApplicantManager("jdbc:derby://localhost:1527/BursaryCareAdvisorDB", "app", "123");

                    Administrator ad = manager.viewAdministrator(username);

                    String Ausername = request.getParameter("logUsername");

                    if (username.equals(ad.getUsername())) {

                        Applicant ap = new Applicant();

                        List<Applicant> applicants = applicantManager.getAllApplicant();

                        String email = ad.getEmail();
                        Integer adminNumber = ad.getAdminNumber();
                        session.setAttribute("applicants", applicants);
                        session.setAttribute("email", email);
                        session.setAttribute("adminNumber", adminNumber);

                        RequestDispatcher d = request.getRequestDispatcher("AdministratorLogin.jsp");
                        d.forward(request, response);

                    } else {

                        String use = "Incorrect Username or Password! ";

                        request.setAttribute("incorrectUsername", use);

                        request.getRequestDispatcher("login.jsp").forward(request, response);

                    }

                } catch (SQLException ex) {
                    Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
                }

            } else if (selectedOption.equalsIgnoreCase("seniorAdministrator")) {

                AdministratorManager manager;
                try {
                    manager = new AdministratorManager("jdbc:derby://localhost:1527/BursaryCareAdvisorDB", "app", "123");
                    ApplicantManager applicantManager = new ApplicantManager("jdbc:derby://localhost:1527/BursaryCareAdvisorDB", "app", "123");

                    Bursary_Interviewer ad = applicantManager.viewBursaryInterviewer(username);

                    String Ausername = request.getParameter("logUsername");

                    if (Ausername.equals(ad.getUsername())) {

                        Applicant ap = new Applicant();

                        List<Applicant> applicants = applicantManager.getAllApplicants();

                        String email = ad.getEmail();
                        Integer adminNumber = ad.getInterviewerID();
                        String name = ad.getName();
                        session.setAttribute("applicants", applicants);
                        session.setAttribute("email", name);
                        session.setAttribute("adminNumber", adminNumber);
                        RequestDispatcher d = request.getRequestDispatcher("SeniorAdministrator.jsp");

                        d.forward(request, response);

                    } else {

                        String use = "Incorrect Username or Password! ";

                        request.setAttribute("incorrectUsername", use);

                        request.getRequestDispatcher("login.jsp").forward(request, response);

                    }

                } catch (SQLException ex) {
                    Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        }

        if (opt.equals(
                "Status")) {

            String status = request.getParameter("status");
            try {
                ApplicantManager applicantManager = new ApplicantManager("jdbc:derby://localhost:1527/BursaryCareAdvisorDB", "app", "123");
                List<Applicant> applicants = (List<Applicant>) session.getAttribute("applicants");
                Applicant app = new Applicant();
                for (int i = 0; i < applicants.size(); i++) {

                    app.setStatus(status);
                    app.setApplicantNumber(applicants.get(i).getApplicantNumber());

                }
                applicantManager.updateStatus(app);
                request.getRequestDispatcher("AdministratorLogin.jsp").forward(request, response);

            } catch (SQLException ex) {
                Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        if (opt.equals(
                "SAVE")) {

            Part imagePart1 = request.getPart("letter");
            Part imagePart2 = request.getPart("image");

            String imageName1 = imagePart1.getSubmittedFileName();
            String imageName2 = imagePart2.getSubmittedFileName();
            byte[] image1Byte = getBytes(imagePart1);
            byte[] image2Byte = getBytes(imagePart2);
            Integer id = (Integer) session.getAttribute("id");

            try {
                ApplicantManager applicantManager = new ApplicantManager("jdbc:derby://localhost:1527/BursaryCareAdvisorDB", "app", "123");
                Applicant app = new Applicant();
                app.setImage(image2Byte);
                app.setLetter(image1Byte);
                app.setApplicantNumber(id);

                applicantManager.update(app);

                session.setAttribute("pic", app);

                request.getRequestDispatcher("ApplicantLogin.jsp").forward(request, response);
            } catch (SQLException ex) {
                Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else if (opt.equals(
                "delete")) {
            try {
                ApplicantManager applicantManager = new ApplicantManager("jdbc:derby://localhost:1527/BursaryCareAdvisorDB", "app", "123");

                Integer id = (Integer) session.getAttribute("id");

                applicantManager.delete(id);

                request.getRequestDispatcher("DeleteApplicantOutcome.jsp").forward(request, response);

            } catch (SQLException ex) {
                Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    public byte[] getBytes(Part imagePart) {
        InputStream ImageInputStream = null;
        byte[] imageBLOB = null;

        try {
            ImageInputStream = imagePart.getInputStream();

            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            byte[] buffer = new byte[1024];
            int byte_imge = 0;
            while ((byte_imge = (ImageInputStream.read(buffer))) != -1) {
                baos.write(buffer, 0, byte_imge);
            }
            imageBLOB = baos.toByteArray();

        } catch (IOException ex) {
            Logger.getLogger(LoginServlet.class
                    .getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                ImageInputStream.close();

            } catch (IOException ex) {
                Logger.getLogger(LoginServlet.class
                        .getName()).log(Level.SEVERE, null, ex);
            }

        }
        return imageBLOB;

    }

}
